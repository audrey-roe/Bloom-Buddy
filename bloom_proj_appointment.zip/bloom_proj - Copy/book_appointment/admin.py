from django.contrib import admin
from . models import appointment

# Register your models here.
admin.site.register(appointment)